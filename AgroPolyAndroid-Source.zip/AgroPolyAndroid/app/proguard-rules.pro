# No custom shrinking rules are needed for this lightweight WebView wrapper.
